import UIKit



protocol Monster {
    var name: String { get }
    func roar() -> String
}


protocol FlyingMonster: Monster {
    var wingSpan: Double { get }
    func fly() -> String
}


protocol WaterMonster: Monster {
    var swimSpeed: Int { get }
    func swim() -> String
}


class Dragon: FlyingMonster {
    var name: String
    var wingSpan: Double
    
    init(name: String, wingSpan: Double) {
        self.name = name
        self.wingSpan = wingSpan
    }
    
    func roar() -> String {
        return "\(name) roars loudly!"
    }
    
    func fly() -> String {
        return "\(name) flies with its \(wingSpan)-meter wings!"
    }
}

class Gryphon: FlyingMonster {
    var name: String
    var wingSpan: Double
    
    init(name: String, wingSpan: Double) {
        self.name = name
        self.wingSpan = wingSpan
    }
    
    func roar() -> String {
        return "\(name) lets out a sharp screech!"
    }
    
    func fly() -> String {
        return "\(name) soars through the sky with its \(wingSpan)-meter wings!"
    }
}

// Class for Kraken, which can Swim
class Kraken: WaterMonster {
    var name: String
    var swimSpeed: Int
    
    init(name: String, swimSpeed: Int) {
        self.name = name
        self.swimSpeed = swimSpeed
    }
    
    func roar() -> String {
        return "\(name) bellows from the ocean depths!"
    }
    
    func swim() -> String {
        return "\(name) moves through the water at \(swimSpeed) knots!"
    }
}


class Merfolk: WaterMonster {
    var name: String
    var swimSpeed: Int
    
    init(name: String, swimSpeed: Int) {
        self.name = name
        self.swimSpeed = swimSpeed
    }
    
    func roar() -> String {
        return "\(name) sings a magical song!"
    }
    
    func swim() -> String {
        return "\(name) swims elegantly at \(swimSpeed) knots!"
    }
}


func printMonsterDetails(monsters: [Monster]) {
    for monster in monsters {
        print(monster.roar())
        
        if let flying = monster as? FlyingMonster {
            print(flying.fly())
        } else if let swimming = monster as? WaterMonster {
            print(swimming.swim())
        }
        
        print("---------------------")
    }
}


let fireDrake = Dragon(name: "Fire Drake", wingSpan: 15.0)
let skyHunter = Gryphon(name: "Sky Hunter", wingSpan: 12.0)
let seaTerror = Kraken(name: "Sea Terror", swimSpeed: 20)
let coralQueen = Merfolk(name: "Coral Queen", swimSpeed: 10)

let monsters: [Monster] = [fireDrake, skyHunter, seaTerror, coralQueen]
printMonsterDetails(monsters: monsters)
